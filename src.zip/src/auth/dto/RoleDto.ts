export enum Role {
  
    Instructor = 'instructor',
    Admin = 'admin',
    student = "student",
  }
  
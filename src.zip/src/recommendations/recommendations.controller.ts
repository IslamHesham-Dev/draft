import { Controller } from '@nestjs/common';

@Controller('recommendations')
export class RecommendationsController {}

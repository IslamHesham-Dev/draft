export class UpdateStudentProfileDto {
  learningPreferences: string[];
  subjectsOfInterest: string[];
}

export class UpdateInstructorProfileDto {
    expertise: string[];
    teachingInterests: string[];
  }
  
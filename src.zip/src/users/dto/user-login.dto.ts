export class LoginUserDto {
    email: string;
    password: string;
  }
  
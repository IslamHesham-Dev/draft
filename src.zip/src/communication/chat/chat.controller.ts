import { Controller } from '@nestjs/common';

@Controller('chat')
export class ChatController {}

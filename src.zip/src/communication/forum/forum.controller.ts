import { Controller } from '@nestjs/common';

@Controller('forum')
export class ForumController {}
